/*
package com.arria.ping.database

import androidx.room.ColumnInfo
import androidx.room.Entity

@Entity
data class StateAndAreaListEntity(
    @ColumnInfo(name = "areaID")
    var areaID: Int,
    @ColumnInfo(name = "stateID")
    var stateID: Int,
)

*/
