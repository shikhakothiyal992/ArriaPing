package com.arria.ping.ui.refreshtoken.model

enum class Status {
    SUCCESS, UNSUCCESSFUL,ERROR, LOADING,OFFLINE
}