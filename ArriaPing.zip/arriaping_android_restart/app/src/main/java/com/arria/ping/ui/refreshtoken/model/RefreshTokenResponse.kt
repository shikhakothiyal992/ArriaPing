package com.arria.ping.ui.refreshtoken.model

data class RefreshTokenResponse(val status: Status)
