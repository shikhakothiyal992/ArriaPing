package  com.arria.ping.model

data class SendRefreshRequest(
        var refreshToken: String,

        )