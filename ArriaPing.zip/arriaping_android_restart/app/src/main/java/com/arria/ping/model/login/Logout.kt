package  com.arria.ping.model.login

data class Logout(
        val message: String,
)
