package  com.arria.ping.model

data class StoreFilterPojo(
        val storeNumber: String,
        var isSelect: Boolean = false
)