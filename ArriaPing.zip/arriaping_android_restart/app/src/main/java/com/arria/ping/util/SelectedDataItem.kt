package com.arria.ping.util

enum class SelectedDataItem(val selectedItem: Int) {
    UNSELECTED_ITEM(1),
    SELECTED_ITEM(2)

}