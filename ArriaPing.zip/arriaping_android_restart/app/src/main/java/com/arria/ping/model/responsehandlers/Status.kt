package com.arria.ping.model.responsehandlers

enum class Status {
    SUCCESS, ERROR, LOADING
}