package com.arria.ping.model.profile

data class UserProfile(
        val firstName: String,
        val lastName: String,
        val role: String,
        val email: String,
        val storeId: String,
)
